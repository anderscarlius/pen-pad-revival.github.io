# Clinergy / PEN&PAD 1998 knowledge, as YAML

Content (c) 1997-8 Semantic Technologies Ltd / Victoria University of Manchester. All rights reserved.
This folder was generated from your own copy of `ClinergyDemo.zip`
(sha256 `f138c38b24de630ce0c89bc8018dbc68fc2b17e040235c9c01e10761d8114270`) by clinergy-extractor 0.1.0 on 2026-11-15.
It is a private study copy: do not redistribute or publish it without the rights holders' permission.

Model version: k_20_00. 7687 named concepts, 2121 form topics,
7442 visible form items on 2057 concepts, 230 examinations.

| Path | Contents |
|---|---|
| `forms/<category>/<Topic>.yaml` | one data-entry form per topic: first-layer and ">>" items in order with their curated values, inheritance flags, associated symptoms/signs, diagnoses, examinations |
| `forms/index.yaml` | form topics with display text and file path |
| `concepts.yaml` | every named concept, keyed by name: ids, display text, category, supertypes, visibility rows, form path |
| `concept-links.yaml` | raw per-concept query results (candidate attributes, sanctions, links) |
| `exams.yaml` | the examination tree: signs, sub-exams, linked symptoms, laterality |
| `sentence-rules.yaml` | descriptor precedences and per-value rules, value precedences, summary types, lexicon |
| `bodymap.yaml` | body-map click areas and selector buttons from the Compdata INI files, linked to their pictures |
| `images/`, `images.yaml` | every picture and icon in the demo as PNG (icons also as .ico): bodymap/, buttons/, bitmaps/, resources/, icons/, metafiles/ |
| `topic-lists.yaml` | short quick-pick lists (common topics, symptoms, ...) |
| `search-space.yaml` | the type-ahead search index |
| `model.yaml` | counts and global lists |
